//
//  YWMessageBodyUnsupported.h
//  
//
//  Created by Jai Chen on 15/1/23.
//  Copyright (c) 2015年 taobao. All rights reserved.
//

#import "YWMessageBody.h"

@interface YWMessageBodyUnsupported : YWMessageBody

@end

@interface YWMessageBodyUnsupported ()

@property (nonatomic, copy) NSManagedObjectID *internalManagedObjectID;

@end