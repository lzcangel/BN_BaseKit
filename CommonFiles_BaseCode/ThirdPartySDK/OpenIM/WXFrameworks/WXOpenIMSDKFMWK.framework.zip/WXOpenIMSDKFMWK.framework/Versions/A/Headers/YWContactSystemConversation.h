//
//  YWContactSystemConversation.h
//  WXOpenIMSDK
//
//  Created by 慕桥(黄玉坤) on 15/11/17.
//  Copyright © 2015年 taobao. All rights reserved.
//

#import "YWConversation.h"

@interface YWContactSystemConversation : YWConversation

@end
